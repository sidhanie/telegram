## bot-telegram

https://img.shields.io/badge/Github-Shoto-blue.svg?style=for-the-badge&logo=github

Bagi bagi bot telegram

## Fitur 



- /mydog  -  Menampilkan gambar anjing imute
- /mycat  -  Menampilkan gambar kucing imute
- /myava  -  Menampilkan gambar avatar gaje tapi imute
- /walhp  -  Menampilkan random wallpaper hp kece
- /picstem - Menampilkan foto profile steam kece
- /fbvid  -  Mendownload video dari fb
- /igvid  -  Mendownload video dari ig
- /twvid  -  Mendownload video dari twitter
- /ytmp4  -  Mendownload video dari youtube
- /ytmp3  -  Mendownload audio dari youtube
- /sms    -  Mengirim sms gratis


## Install 

Kali,Ubuntu,Linux
```
sudo apt install python

sudo apt install python3

sudo apt install python-pip

git clone https://github.com/INDOHACKER-XODE/Bot-Telegram

cd bot-telegram

pip3 install -r requirements.txt

nano mainbot.py

ctrl w

updaterr = Updater(os.getenv('TOKEN-KEY'),use_context=True)

ganti TOKEN-KEY nya

ctrl x+y

python mainbot.py
```

Windows
[download python3](https://www.python.org/downloads/)



